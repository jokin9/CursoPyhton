# Este archivo creado en la raiz del paquete es para instalar el paquete mensajes (de manera local) en python 
# para poder utilizarlo en cualquier otro lado

# Lo que vamos a hacer aca es crear una configuracion para la biblioteca setup tools

from setuptools import setup

setup(
    name = 'mensajes',
    version = '1.0',
    description = 'Un paquete para saludar y despedir',
    author = 'Joaquin Corbo Pereira',
    author_email = 'jokin5249149@gmail.com',
    url = '',
    packages = ['mensajes', 'mensajes.hola', 'mensajes.adios'],
    scripts = ['test.py']
)