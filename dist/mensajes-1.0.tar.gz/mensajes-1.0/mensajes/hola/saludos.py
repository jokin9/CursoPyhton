def saludar():
    print("Hola, te saludo desde saludos.saludar()")

class Saludo:
    def __init__(self):
        print("Hola te saludo desde Saludo.__init__()")

if __name__ == '__main__': # La variable name, almacena durante la ejecucion de un programa el nombre del script
    saludar()