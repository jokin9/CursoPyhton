def despedir():
    print('Adios, me despido desde desdpedidas.despedir()')

class Despedida:
    
    def __init__(self):
        print('Adios, me despido desde Despedida.__init__()')